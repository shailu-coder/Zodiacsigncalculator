package com.example.zodiacsigncalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    Button button;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.button);
        textView= findViewById(R.id.textView);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, MainActivity.this,
                        year, month, day);
                datePickerDialog.show();
            }
        });
    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        textView.setText("your zodiac sign is " + getZodiacSign(i2, i1));
    }

    private String getZodiacSign(int day, int month){
        String zodiacZign ="";

        //month 0= january

        if (month==0){
            if (day<20){
                zodiacZign= "Capricorn";
            }else {
                zodiacZign = "Aquarius";
            }
        }else if (month==1){
            if (day<20){
                zodiacZign= "Aquarius";
            }else {
                zodiacZign = "Pisces";
            }
        }else if (month==2){
            if (day<20){
                zodiacZign= "Pisces";
            }else {
                zodiacZign = "Aries";
            }
        }else if (month==3){
            if (day<20){
                zodiacZign= "Aries";
            }else {
                zodiacZign = "Taurus";
            }
        }else if (month==4){
            if (day<20){
                zodiacZign= "Taurus";
            }else {
                zodiacZign = "Gemini";
            }
        }else if (month==5){
            if (day<20){
                zodiacZign= "Gemini";
            }else {
                zodiacZign = "Cancer";
            }
        }else if (month==6){
            if (day<20){
                zodiacZign= "Cancer";
            }else {
                zodiacZign = "Leo";
            }
        }else if (month==7){
            if (day<20){
                zodiacZign= "Leo";
            }else {
                zodiacZign = "Virgo";
            }
        }else if (month==8){
            if (day<20){
                zodiacZign= "Virgo";
            }else {
                zodiacZign = "Libra";
            }
        }else if (month==9){
            if (day<20){
                zodiacZign= "Libra";
            }else {
                zodiacZign = "Scorpio";
            }
        }else if (month==10){
            if (day<20){
                zodiacZign= "Scorpio";
            }else {
                zodiacZign = "Sagittarius";
            }
        }else if (month==11){
            if (day<20){
                zodiacZign= "Sagittarius";
            }else {
                zodiacZign = "Capricorn";
            }
        }

        return zodiacZign;
    }
}
